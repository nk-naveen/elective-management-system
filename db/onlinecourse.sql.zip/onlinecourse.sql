-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 01, 2022 at 08:21 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinecourse`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `creationDate`, `updationDate`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '2020-01-24 16:21:18', '03-06-2020 07:09:07 PM');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `courseCode` varchar(255) NOT NULL,
  `courseName` varchar(255) NOT NULL,
  `noofSeats` int(11) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) NOT NULL,
  `semester` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `courseCode`, `courseName`, `noofSeats`, `creationDate`, `updationDate`, `semester`) VALUES
(3, '261', 'CYBER SECUIRTY AND CYBER LAW', 50, '2022-01-29 06:56:31', '', 'semester2'),
(4, '262', 'MANAGEMENT FOR IT INDUSTRY', 40, '2022-01-29 06:57:14', '30-01-2022 12:20:22 PM', 'semester2'),
(5, '263', 'INTERNET OF THINGS', 20, '2022-01-29 06:57:33', '', 'semester2'),
(6, '264', 'ADVANCED COMPUTER NETWORKS', 40, '2022-01-29 06:57:52', '', 'semester2'),
(7, '265', 'SOFTWARE TESTING', 20, '2022-01-29 06:58:07', '01-02-2022 11:38:19 AM', 'semester2'),
(8, '271', 'DIGITAL MARKETING', 1, '2022-01-29 06:58:22', '', 'semester2'),
(9, '272', 'SOFTWARE PROJECT MANAGEMENT', 40, '2022-01-29 06:58:42', '', 'semester2'),
(10, '273', 'INFORMATION NETWORK SECURITY', 40, '2022-01-29 06:59:20', '', 'semester2'),
(11, '274', 'DISTRIBUTED SYSTEMS', 40, '2022-01-29 06:59:39', '', 'semester2'),
(12, '275', 'ADVANCED PYTHON', 1, '2022-01-29 07:00:08', '', 'semester2'),
(14, '266', 'Java', 40, '2022-01-30 05:58:18', '', 'semester2'),
(22, '351', 'Recommender system', 0, '2022-01-30 06:41:02', '', 'semester3'),
(23, '352', 'R programming', 20, '2022-01-30 06:41:22', '', 'semester3'),
(24, '353', 'Cloud Computing', 40, '2022-01-30 06:41:42', '', 'semester3'),
(27, '354', 'ADVANCED DBMS', 40, '2022-01-30 06:46:46', '', 'semester3'),
(28, '355', 'INFORMATION STORAGE NETWROKS', 50, '2022-01-30 06:48:07', '30-01-2022 12:20:59 PM', 'semester3'),
(29, '361', 'NOsql', 20, '2022-01-30 06:48:25', '', 'semester3'),
(30, '362', 'Full stack Development', 30, '2022-01-30 06:48:46', '', 'semester3'),
(31, '363', 'Artificial Intelligence', 30, '2022-01-30 06:49:09', '', 'semester3'),
(32, '364', 'Block Chain Technology', 60, '2022-01-30 06:49:33', '', 'semester3'),
(33, '365', 'Information Retrieval', 40, '2022-01-30 06:50:02', '', 'semester3');

-- --------------------------------------------------------

--
-- Table structure for table `courseenrolls`
--

CREATE TABLE `courseenrolls` (
  `id` int(11) NOT NULL,
  `studentRegno` varchar(255) NOT NULL,
  `pincode` varchar(255) NOT NULL,
  `semester` varchar(11) NOT NULL,
  `course1` varchar(40) NOT NULL,
  `course2` varchar(100) NOT NULL,
  `enrollDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courseenrolls`
--

INSERT INTO `courseenrolls` (`id`, `studentRegno`, `pincode`, `semester`, `course1`, `course2`, `enrollDate`) VALUES
(1, '2GI20MC011', '20p3302', 'semester3', '22', '30', '2022-01-30 15:55:37'),
(2, '2GI20MC035', '20p3301', 'semester2', '5', '8', '2022-01-30 18:14:17'),
(3, '2GI20MC011', '20p3302', 'semester3', '22', '30', '2022-01-31 06:22:40'),
(4, '2GI20MC035', '20p3301', 'semester2', '6', '12', '2022-01-31 06:27:14'),
(5, '2GI20MC002', '20p3002', 'semester2', '3', '9', '2022-02-01 06:15:29');

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `id` int(11) NOT NULL,
  `semester` varchar(255) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`id`, `semester`, `creationDate`, `updationDate`) VALUES
(1, 'semester2', '2022-01-05 01:37:54', ''),
(2, 'semester3', '2022-01-05 01:37:54', '');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `StudentRegno` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `studentName` varchar(255) NOT NULL,
  `pincode` varchar(255) NOT NULL,
  `semester` varchar(255) NOT NULL,
  `creationdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`StudentRegno`, `password`, `studentName`, `pincode`, `semester`, `creationdate`, `updationDate`) VALUES
('2GI20MC001', '123', 'Manoj ', '20p3001', 'semester2', '2022-02-01 06:00:04', ''),
('2GI20MC002', '123', 'Darshan', '20p3002', 'semester2', '2022-02-01 06:00:04', '01-02-2022 11:42:08 AM'),
('2GI20MC003', '123', 'Suraj', '20p3003', 'semester2', '2022-02-01 06:00:04', ''),
('2GI20MC004', '123', 'Navneet', '20p3004', 'semester2', '2022-02-01 06:00:04', ''),
('2GI20MC005', '123', 'Samarth', '20p3005', 'semester2', '2022-02-01 06:00:05', ''),
('2GI20MC006', '123', 'Naveen', '20p3006', 'semester2', '2022-02-01 06:00:05', ''),
('2GI20MC007', '123', 'Amogh', '20p3007', 'semester2', '2022-02-01 06:00:05', ''),
('2GI20MC008', '123', 'Vinay', '20p3008', 'semester2', '2022-02-01 06:00:05', '');

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `studentRegno` varchar(255) NOT NULL,
  `userip` binary(16) NOT NULL,
  `loginTime` timestamp NOT NULL DEFAULT current_timestamp(),
  `logout` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `studentRegno`, `userip`, `loginTime`, `logout`, `status`) VALUES
(1, 'MCAGIT09', 0x3a3a3100000000000000000000000000, '2022-01-03 16:09:19', '', 1),
(2, 'MCAGIT09', 0x3a3a3100000000000000000000000000, '2022-01-04 03:38:34', '', 1),
(3, 'MCAGIT09', 0x3a3a3100000000000000000000000000, '2022-01-05 01:32:14', '', 1),
(4, '2gi2001', 0x3a3a3100000000000000000000000000, '2022-01-26 06:59:14', '', 1),
(5, '2gi2001', 0x3a3a3100000000000000000000000000, '2022-01-26 07:02:38', '', 1),
(6, '2gi2001', 0x3a3a3100000000000000000000000000, '2022-01-26 07:07:30', '', 1),
(7, '2gi2001', 0x3a3a3100000000000000000000000000, '2022-01-28 09:49:46', '', 1),
(8, '11', 0x3a3a3100000000000000000000000000, '2022-01-28 17:43:49', '', 1),
(9, '2gi2001', 0x3a3a3100000000000000000000000000, '2022-01-28 18:26:45', '', 1),
(10, '2gi2001', 0x3a3a3100000000000000000000000000, '2022-01-29 07:04:43', '', 1),
(11, '2gi2001', 0x3a3a3100000000000000000000000000, '2022-01-30 05:45:27', '', 1),
(12, '2gi2001', 0x3a3a3100000000000000000000000000, '2022-01-30 05:59:29', '', 1),
(13, '2gi2002', 0x3a3a3100000000000000000000000000, '2022-01-30 08:43:09', '30-01-2022 02:14:49 PM', 1),
(14, '2GI20MC011', 0x3a3a3100000000000000000000000000, '2022-01-30 15:52:12', '', 1),
(15, 'mca02', 0x3a3a3100000000000000000000000000, '2022-01-30 17:39:06', '30-01-2022 11:17:18 PM', 1),
(16, '2GI20MC035', 0x3a3a3100000000000000000000000000, '2022-01-30 17:47:28', '30-01-2022 11:44:41 PM', 1),
(17, '2GI20MC011', 0x3a3a3100000000000000000000000000, '2022-01-30 18:14:57', '31-01-2022 12:14:26 AM', 1),
(18, '2GI20MC011', 0x3a3a3100000000000000000000000000, '2022-01-30 18:44:36', '31-01-2022 12:16:37 AM', 1),
(19, '2GI20MC011', 0x3a3a3100000000000000000000000000, '2022-01-30 18:46:42', '', 1),
(20, '2GI20MC011', 0x3a3a3100000000000000000000000000, '2022-01-31 05:55:39', '31-01-2022 11:28:11 AM', 1),
(21, '2GI20MC011', 0x3a3a3100000000000000000000000000, '2022-01-31 05:58:16', '31-01-2022 11:38:14 AM', 1),
(22, '2GI20MC011', 0x3a3a3100000000000000000000000000, '2022-01-31 06:13:49', '31-01-2022 11:55:58 AM', 1),
(23, '2GI20MC035', 0x3a3a3100000000000000000000000000, '2022-01-31 06:26:06', '31-01-2022 11:57:18 AM', 1),
(24, '2GI20MC011', 0x3a3a3100000000000000000000000000, '2022-01-31 06:27:27', '31-01-2022 12:14:59 PM', 1),
(25, '2GI20MC011', 0x3a3a3100000000000000000000000000, '2022-01-31 09:17:04', '31-01-2022 02:48:57 PM', 1),
(26, '2GI20MC001', 0x3a3a3100000000000000000000000000, '2022-02-01 06:00:12', '', 1),
(27, '2GI20MC002', 0x3a3a3100000000000000000000000000, '2022-02-01 06:07:13', '', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courseenrolls`
--
ALTER TABLE `courseenrolls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`StudentRegno`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `courseenrolls`
--
ALTER TABLE `courseenrolls`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `semester`
--
ALTER TABLE `semester`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
